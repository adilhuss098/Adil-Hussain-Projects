"""
generate_data.py
----------------
Generates a synthetic pipe network dataset that replicates the structure
and statistical properties described in:

  Winkler et al. (2018) - Pipe failure modelling for water distribution
  networks using boosted decision trees.
  Structure and Infrastructure Engineering, 14(10), 1402-1411.

Dataset properties (matching the paper):
  - ~39,637 pipes
  - 9 pipe materials with exact % breakdown from the paper
  - 12 features (age, diameter, length, pressure, material, type, etc.)
  - ~8.63% failure rate (skewed data - as in the real case study)
  - Failure probability driven by age, material, and pipe type
"""

import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)

# ── Configuration matching paper exactly ──────────────────────────────────────
N_PIPES = 39_637

MATERIAL_DIST = {
    "AC":  0.0346,   # asbestos cement
    "CI":  0.0692,   # cast iron
    "DI":  0.0705,   # ductile iron
    "GRP": 0.0001,   # glass reinforced plastic
    "PP":  0.0170,   # polypropylene
    "PE":  0.5183,   # polyethylene  (dominant)
    "PVC": 0.0843,   # polyvinyl chloride
    "Pb":  0.0006,   # lead
    "ST":  0.2054,   # steel
}

TYPE_DIST = {"HC": 0.69, "DP": 0.25, "HY": 0.06}

# Installation year ranges by material (from paper Table 1 / domain knowledge)
MATERIAL_INSTALL_RANGE = {
    "AC":  (1940, 1980),
    "CI":  (1900, 1970),
    "DI":  (1960, 2010),
    "GRP": (1980, 2010),
    "PP":  (1970, 2010),
    "PE":  (1975, 2018),
    "PVC": (1960, 2015),
    "Pb":  (1900, 1960),
    "ST":  (1920, 2000),
}

# Diameter distributions by pipe type (mm)
DIAMETER_BY_TYPE = {
    "HC": (20, 50),    # 72% of pipes < 50mm
    "DP": (80, 300),
    "HY": (50, 150),
}

# Base failure rates per material (higher = more prone to failure)
MATERIAL_FAILURE_BASE = {
    "AC":  0.35,
    "CI":  0.30,
    "DI":  0.10,
    "GRP": 0.05,
    "PP":  0.08,
    "PE":  0.04,
    "PVC": 0.06,
    "Pb":  0.40,
    "ST":  0.18,
}

REFERENCE_YEAR = 2018


def generate_pipes(n=N_PIPES):
    records = []

    materials = np.random.choice(
        list(MATERIAL_DIST.keys()),
        size=n,
        p=list(MATERIAL_DIST.values())
    )

    pipe_types = np.random.choice(
        list(TYPE_DIST.keys()),
        size=n,
        p=list(TYPE_DIST.values())
    )

    for i, (mat, ptype) in enumerate(zip(materials, pipe_types)):
        yr_min, yr_max = MATERIAL_INSTALL_RANGE[mat]
        install_year = int(np.random.uniform(yr_min, yr_max))
        age = REFERENCE_YEAR - install_year

        d_min, d_max = DIAMETER_BY_TYPE[ptype]
        diameter = int(np.random.uniform(d_min, d_max))

        # Length: log-normal, house connections shorter
        if ptype == "HC":
            length = round(np.random.lognormal(mean=0.5, sigma=0.6), 2)
        else:
            length = round(np.random.lognormal(mean=1.5, sigma=0.7), 2)

        pressure = 0.5   # 99% of pipes recorded at 0.5 MPa (paper states this)
        if np.random.rand() < 0.01:
            pressure = round(np.random.choice([0.3, 0.4, 0.6, 0.8]), 1)

        # Geographic / network context
        hc_str     = int(np.random.poisson(3))
        hy_str     = int(np.random.poisson(1))
        valves_tot = int(np.random.poisson(2))
        valves_st  = int(np.random.poisson(1))

        # Failure probability model (replicates paper patterns)
        age_factor    = min(age / 80.0, 1.0)
        mat_base      = MATERIAL_FAILURE_BASE[mat]
        length_factor = min(length / 10.0, 1.0) * 0.15
        p_fail = mat_base * (0.4 + 0.6 * age_factor) + length_factor

        # Correlated past failures
        n_total_failures = np.random.poisson(p_fail * 3)
        n_new_failures   = min(n_total_failures, np.random.poisson(p_fail * 2))

        # Current failure label
        failure_label = int(np.random.rand() < p_fail * 0.6)

        records.append({
            "pipe_id":        i,
            "material":       mat,
            "type":           ptype,
            "install_year":   install_year,
            "age":            age,
            "diameter":       diameter,
            "length":         length,
            "pressure":       pressure,
            "HC_Str":         hc_str,
            "HY_Str":         hy_str,
            "Valves_Tot":     valves_tot,
            "Valves_St":      valves_st,
            "Failure_Tot":    n_total_failures,
            "Failure_New":    n_new_failures,
            "failure":        failure_label,
        })

    df = pd.DataFrame(records)

    # ── Post-processing: enforce target failure rate of ~8.63% ────────────────
    current_rate = df["failure"].mean()
    target_rate  = 0.0863

    if current_rate > target_rate:
        # Randomly flip some failures to 0 to reduce rate
        fail_idx   = df[df["failure"] == 1].index
        n_to_flip  = int(len(fail_idx) - target_rate * n)
        n_to_flip  = max(0, n_to_flip)
        flip_idx   = np.random.choice(fail_idx, size=min(n_to_flip, len(fail_idx)), replace=False)
        df.loc[flip_idx, "failure"] = 0
    elif current_rate < target_rate:
        no_fail_idx = df[df["failure"] == 0].index
        n_to_flip   = int(target_rate * n - len(df[df["failure"] == 1]))
        n_to_flip   = max(0, n_to_flip)
        flip_idx    = np.random.choice(no_fail_idx, size=min(n_to_flip, len(no_fail_idx)), replace=False)
        df.loc[flip_idx, "failure"] = 1

    return df


if __name__ == "__main__":
    print("Generating synthetic pipe network dataset...")
    df = generate_pipes()

    out_path = Path("data/pipe_network.csv")
    out_path.parent.mkdir(exist_ok=True)
    df.to_csv(out_path, index=False)

    print(f"  Total pipes:      {len(df):,}")
    print(f"  Failure rate:     {df['failure'].mean():.2%}")
    print(f"  Total failures:   {df['failure'].sum():,}")
    print(f"  Materials:        {df['material'].nunique()}")
    print(f"  Saved to:         {out_path}")
